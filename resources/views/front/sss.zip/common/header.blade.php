<?php 
$page = '';
$slug = isset($vendor->slug) ? $vendor->slug :'';
$segments_arr = request()->segments();
$seg1 = isset($segments_arr[0]) ? $segments_arr[0] :'';
$seg2 = isset($segments_arr[1]) ? $segments_arr[1] :'';
$name = isset(Auth::guard('appusers')->user()->name) ? Auth::guard('appusers')->user()->name :'User';
	

if($seg1 == $slug){
	$page = 'home';
}if($seg2 == 'cart'){
	$page = 'cart';
}

$url = url('/').'/'.$slug;
$imgUrl = asset('public/assets/front/images/avatars/1.jpg');
if(!empty(Auth::guard('appusers')->user()->image)){
$imgUrl = Auth::guard('appusers')->user()->image;
}
?>

<!DOCTYPE HTML>
<html lang="en">

<head>
<meta charset="utf-8">
<meta http-equiv="pragma" content="no-cache" />
<meta http-equiv="cache-control" content="max-age=604800" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no">

<title>Front Web</title>

<link href="{{asset('public/assets/front/images/favicon.ico')}}" rel="shortcut icon" type="image/x-icon">
<script src="{{asset('public/assets/front/js/jquery-2.0.0.min.js')}}" type="text/javascript"></script>

<!-- Bootstrap4 files-->
<script src="{{asset('public/assets/front/js/bootstrap.bundle.min.js')}}" type="text/javascript"></script>
<link href="{{asset('public/assets/front/css/bootstrap.css')}}" rel="stylesheet" type="text/css"/>

<!-- Font awesome 5 -->
<link href="{{asset('public/assets/front/fonts/fontawesome/css/all.min.css')}}" type="text/css" rel="stylesheet">

<!-- custom style -->
<link href="{{asset('public/assets/front/css/mobile.css')}}" rel="stylesheet" type="text/css"/>


<!-- custom javascript -->
<script src="{{asset('public/assets/front/js/script.js')}}" type="text/javascript"></script>
<!-- plugin: fancybox  -->
<script src="{{asset('public/assets/front/plugins/fancybox/fancybox.min.js')}}" type="text/javascript"></script>
<link href="{{asset('public/assets/front/plugins/fancybox/fancybox.min.css')}}" type="text/css" rel="stylesheet">
<script type="text/javascript">
/// some script

// jquery ready start
$(document).ready(function() {
	// jQuery code

}); 
// jquery end
</script>
<style type="text/css">
	body{
		max-width: 500px;
  		margin: auto;
	}
</style>
</head>

<body>
<i class="screen-overlay"></i>

<aside class="offcanvas" id="sidebar_left">
	<div class="card-body bg-primary">
		<button class="btn-close close text-white">&times;</button>
		<img src="{{$imgUrl}}" class="img-sm rounded-circle" alt="">
		<h6 class="text-white mt-3 mb-0">Welcome {{$name}}!</h6>
	</div>
	<nav class="nav-sidebar">
		<a href="{{$url}}"> <i class="fa fa-home"></i> Home</a>
		<a href="{{url($slug.'/all-category')}}"> <i class="fa fa-th"></i>	Categories</a>
		<!-- <a href="#">  <i class="fa fa-info-circle"></i> About us</a> -->
		<!-- <a href="index.html">  <i class="fa fa-building"></i> Company</a> -->
		<a href="{{$url.'/profile'}}">  <i class="fa fa-cog"></i> Settings</a>
		<!-- <a href="index.html"> <i class="fa fa-home"></i> All screens</a> -->
	</nav>
	<hr>
	<nav class="nav-sidebar">
		<a href="#"> <i class="fa fa-phone"></i> +91{{$vendor->phone ?? ''}}</a>
		<a href="#"> <i class="fa fa-envelope"></i> {{$vendor->email ?? ''}}</a>
		<a href="#"> <i class="fa fa-map-marker"></i>{{$vendor->address ?? ''}}</a>
	</nav>
</aside>
 