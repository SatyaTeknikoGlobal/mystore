@include('front.common.header')


<div class="screen-wrap">


<header class="app-header header-search bg-primary">
    <a href="javascript:history.go(-1)" class="btn-header"><i class="fa fa-arrow-left"></i></a>
   
	<input type="text" autofocus placeholder="Search Coupons" id="secrch_keyword" name="secrch" class="form-control input-dark border-0">
    
</header> <!-- section-header.// -->
<main class="app-content">
 
	
<div id="search_suggetion">
	
</div>

</section>

</main>
</div> 

@include('front.common.footer')

